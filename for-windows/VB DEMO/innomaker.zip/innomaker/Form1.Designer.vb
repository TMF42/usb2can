﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Public sub InitializeComponent()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.numbersendTextBox = New System.Windows.Forms.TextBox()
        Me.SendIntervalTextBox = New System.Windows.Forms.TextBox()
        Me.FrameIdTextBox = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.DataTextBox = New System.Windows.Forms.TextBox()
        Me.BaudRateComboBox = New System.Windows.Forms.ComboBox()
        Me.modeComboBox = New System.Windows.Forms.ComboBox()
        Me.formatComboBox = New System.Windows.Forms.ComboBox()
        Me.typeComboBox = New System.Windows.Forms.ComboBox()
        Me.OpenDeviceBtn = New System.Windows.Forms.Button()
        Me.DelayedSendBtn = New System.Windows.Forms.Button()
        Me.deviceComboBox = New System.Windows.Forms.ComboBox()
        Me.IDAutoIncCheckBox = New System.Windows.Forms.CheckBox()
        Me.scandeviceBtn = New System.Windows.Forms.Button()
        Me.DataAutoIncCheckBox = New System.Windows.Forms.CheckBox()
        Me.hideErrorFrameCheckBox = New System.Windows.Forms.CheckBox()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.sendbtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ListView1
        '
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(12, 238)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(842, 359)
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'numbersendTextBox
        '
        Me.numbersendTextBox.Location = New System.Drawing.Point(166, 136)
        Me.numbersendTextBox.Name = "numbersendTextBox"
        Me.numbersendTextBox.Size = New System.Drawing.Size(66, 20)
        Me.numbersendTextBox.TabIndex = 1
        '
        'SendIntervalTextBox
        '
        Me.SendIntervalTextBox.Location = New System.Drawing.Point(453, 140)
        Me.SendIntervalTextBox.Name = "SendIntervalTextBox"
        Me.SendIntervalTextBox.Size = New System.Drawing.Size(53, 20)
        Me.SendIntervalTextBox.TabIndex = 2
        '
        'FrameIdTextBox
        '
        Me.FrameIdTextBox.Location = New System.Drawing.Point(406, 90)
        Me.FrameIdTextBox.Name = "FrameIdTextBox"
        Me.FrameIdTextBox.Size = New System.Drawing.Size(100, 20)
        Me.FrameIdTextBox.TabIndex = 3
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(12, 212)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(828, 20)
        Me.TextBox2.TabIndex = 4
        '
        'DataTextBox
        '
        Me.DataTextBox.Location = New System.Drawing.Point(658, 93)
        Me.DataTextBox.Name = "DataTextBox"
        Me.DataTextBox.Size = New System.Drawing.Size(144, 20)
        Me.DataTextBox.TabIndex = 5
        '
        'BaudRateComboBox
        '
        Me.BaudRateComboBox.FormattingEnabled = True
        Me.BaudRateComboBox.Location = New System.Drawing.Point(105, 90)
        Me.BaudRateComboBox.Name = "BaudRateComboBox"
        Me.BaudRateComboBox.Size = New System.Drawing.Size(96, 21)
        Me.BaudRateComboBox.TabIndex = 6
        '
        'modeComboBox
        '
        Me.modeComboBox.FormattingEnabled = True
        Me.modeComboBox.Location = New System.Drawing.Point(424, 54)
        Me.modeComboBox.Name = "modeComboBox"
        Me.modeComboBox.Size = New System.Drawing.Size(86, 21)
        Me.modeComboBox.TabIndex = 7
        '
        'formatComboBox
        '
        Me.formatComboBox.FormattingEnabled = True
        Me.formatComboBox.Location = New System.Drawing.Point(105, 54)
        Me.formatComboBox.Name = "formatComboBox"
        Me.formatComboBox.Size = New System.Drawing.Size(96, 21)
        Me.formatComboBox.TabIndex = 8
        '
        'typeComboBox
        '
        Me.typeComboBox.FormattingEnabled = True
        Me.typeComboBox.Location = New System.Drawing.Point(261, 54)
        Me.typeComboBox.Name = "typeComboBox"
        Me.typeComboBox.Size = New System.Drawing.Size(100, 21)
        Me.typeComboBox.TabIndex = 9
        '
        'OpenDeviceBtn
        '
        Me.OpenDeviceBtn.Location = New System.Drawing.Point(465, 10)
        Me.OpenDeviceBtn.Name = "OpenDeviceBtn"
        Me.OpenDeviceBtn.Size = New System.Drawing.Size(111, 23)
        Me.OpenDeviceBtn.TabIndex = 10
        Me.OpenDeviceBtn.Text = "Open device"
        Me.OpenDeviceBtn.UseVisualStyleBackColor = True
        '
        'DelayedSendBtn
        '
        Me.DelayedSendBtn.Location = New System.Drawing.Point(28, 174)
        Me.DelayedSendBtn.Name = "DelayedSendBtn"
        Me.DelayedSendBtn.Size = New System.Drawing.Size(117, 23)
        Me.DelayedSendBtn.TabIndex = 11
        Me.DelayedSendBtn.Text = "Delayed send"
        Me.DelayedSendBtn.UseVisualStyleBackColor = True
        '
        'deviceComboBox
        '
        Me.deviceComboBox.FormattingEnabled = True
        Me.deviceComboBox.Location = New System.Drawing.Point(180, 10)
        Me.deviceComboBox.Name = "deviceComboBox"
        Me.deviceComboBox.Size = New System.Drawing.Size(161, 21)
        Me.deviceComboBox.TabIndex = 12
        '
        'IDAutoIncCheckBox
        '
        Me.IDAutoIncCheckBox.AutoSize = True
        Me.IDAutoIncCheckBox.Location = New System.Drawing.Point(533, 143)
        Me.IDAutoIncCheckBox.Name = "IDAutoIncCheckBox"
        Me.IDAutoIncCheckBox.Size = New System.Drawing.Size(65, 17)
        Me.IDAutoIncCheckBox.TabIndex = 13
        Me.IDAutoIncCheckBox.Text = "Auto inc"
        Me.IDAutoIncCheckBox.UseVisualStyleBackColor = True
        '
        'scandeviceBtn
        '
        Me.scandeviceBtn.Location = New System.Drawing.Point(28, 10)
        Me.scandeviceBtn.Name = "scandeviceBtn"
        Me.scandeviceBtn.Size = New System.Drawing.Size(127, 23)
        Me.scandeviceBtn.TabIndex = 15
        Me.scandeviceBtn.Text = "Scan for device(s) >"
        Me.scandeviceBtn.UseVisualStyleBackColor = True
        '
        'DataAutoIncCheckBox
        '
        Me.DataAutoIncCheckBox.AutoSize = True
        Me.DataAutoIncCheckBox.Location = New System.Drawing.Point(621, 143)
        Me.DataAutoIncCheckBox.Name = "DataAutoIncCheckBox"
        Me.DataAutoIncCheckBox.Size = New System.Drawing.Size(90, 17)
        Me.DataAutoIncCheckBox.TabIndex = 16
        Me.DataAutoIncCheckBox.Text = "Data auto inc"
        Me.DataAutoIncCheckBox.UseVisualStyleBackColor = True
        '
        'hideErrorFrameCheckBox
        '
        Me.hideErrorFrameCheckBox.AutoSize = True
        Me.hideErrorFrameCheckBox.Location = New System.Drawing.Point(739, 143)
        Me.hideErrorFrameCheckBox.Name = "hideErrorFrameCheckBox"
        Me.hideErrorFrameCheckBox.Size = New System.Drawing.Size(101, 17)
        Me.hideErrorFrameCheckBox.TabIndex = 17
        Me.hideErrorFrameCheckBox.Text = "Hide error frame"
        Me.hideErrorFrameCheckBox.UseVisualStyleBackColor = True
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.label9.Location = New System.Drawing.Point(511, 93)
        Me.label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(115, 13)
        Me.label9.TabIndex = 19
        Me.label9.Text = "Data (Input Eight Hex):"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.label8.Location = New System.Drawing.Point(262, 93)
        Me.label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(132, 13)
        Me.label8.TabIndex = 18
        Me.label8.Text = "Frame ID (Input Four Hex):"
        '
        'sendbtn
        '
        Me.sendbtn.Location = New System.Drawing.Point(180, 174)
        Me.sendbtn.Name = "sendbtn"
        Me.sendbtn.Size = New System.Drawing.Size(75, 23)
        Me.sendbtn.TabIndex = 20
        Me.sendbtn.Text = "Send"
        Me.sendbtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(349, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "< Device index"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Format"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(384, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Mode"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(224, 54)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Type"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 93)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "Baud rate"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(130, 13)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "Number to send (1-10000)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(285, 143)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(149, 13)
        Me.Label7.TabIndex = 27
        Me.Label7.Text = "Send interval (100ms-5000ms)"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(866, 609)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.sendbtn)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.hideErrorFrameCheckBox)
        Me.Controls.Add(Me.DataAutoIncCheckBox)
        Me.Controls.Add(Me.scandeviceBtn)
        Me.Controls.Add(Me.IDAutoIncCheckBox)
        Me.Controls.Add(Me.deviceComboBox)
        Me.Controls.Add(Me.DelayedSendBtn)
        Me.Controls.Add(Me.OpenDeviceBtn)
        Me.Controls.Add(Me.typeComboBox)
        Me.Controls.Add(Me.formatComboBox)
        Me.Controls.Add(Me.modeComboBox)
        Me.Controls.Add(Me.BaudRateComboBox)
        Me.Controls.Add(Me.DataTextBox)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.FrameIdTextBox)
        Me.Controls.Add(Me.SendIntervalTextBox)
        Me.Controls.Add(Me.numbersendTextBox)
        Me.Controls.Add(Me.ListView1)
        Me.Name = "Form1"
        Me.Text = "InnoMakerUSB2Can in VB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents numbersendTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SendIntervalTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FrameIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents DataTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BaudRateComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents modeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents formatComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents typeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents OpenDeviceBtn As System.Windows.Forms.Button
    Friend WithEvents DelayedSendBtn As System.Windows.Forms.Button
    Friend WithEvents deviceComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents IDAutoIncCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents scandeviceBtn As Button
    Friend WithEvents DataAutoIncCheckBox As CheckBox
    Friend WithEvents hideErrorFrameCheckBox As CheckBox
    Private WithEvents label9 As Label
    Private WithEvents label8 As Label
    Friend WithEvents sendbtn As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class
