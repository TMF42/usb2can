﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListView = New System.Windows.Forms.ListView
        Me.numbersendTextBox = New System.Windows.Forms.TextBox
        Me.SendIntervalTextBox = New System.Windows.Forms.TextBox
        Me.FrameIdTextBox = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.DataTextBox = New System.Windows.Forms.TextBox
        Me.BaudRateComboBox = New System.Windows.Forms.ComboBox
        Me.modeComboBox = New System.Windows.Forms.ComboBox
        Me.formatComboBox = New System.Windows.Forms.ComboBox
        Me.typeComboBox = New System.Windows.Forms.ComboBox
        Me.OpenDeviceBtn = New System.Windows.Forms.Button
        Me.DelayedSendBtn = New System.Windows.Forms.Button
        Me.deviceComboBox = New System.Windows.Forms.ComboBox
        Me.IDAutoIncCheckBox = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'ListView
        '
        Me.ListView.Location = New System.Drawing.Point(0, 0)
        Me.ListView.Name = "ListView"
        Me.ListView.Size = New System.Drawing.Size(121, 97)
        Me.ListView.TabIndex = 0
        Me.ListView.UseCompatibleStateImageBehavior = False
        '
        'numbersendTextBox
        '
        Me.numbersendTextBox.Location = New System.Drawing.Point(12, 112)
        Me.numbersendTextBox.Name = "numbersendTextBox"
        Me.numbersendTextBox.Size = New System.Drawing.Size(100, 20)
        Me.numbersendTextBox.TabIndex = 1
        '
        'SendIntervalTextBox
        '
        Me.SendIntervalTextBox.Location = New System.Drawing.Point(12, 156)
        Me.SendIntervalTextBox.Name = "SendIntervalTextBox"
        Me.SendIntervalTextBox.Size = New System.Drawing.Size(100, 20)
        Me.SendIntervalTextBox.TabIndex = 2
        '
        'FrameIdTextBox
        '
        Me.FrameIdTextBox.Location = New System.Drawing.Point(12, 197)
        Me.FrameIdTextBox.Name = "FrameIdTextBox"
        Me.FrameIdTextBox.Size = New System.Drawing.Size(100, 20)
        Me.FrameIdTextBox.TabIndex = 3
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(12, 253)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 4
        '
        'DataTextBox
        '
        Me.DataTextBox.Location = New System.Drawing.Point(12, 292)
        Me.DataTextBox.Name = "DataTextBox"
        Me.DataTextBox.Size = New System.Drawing.Size(100, 20)
        Me.DataTextBox.TabIndex = 5
        '
        'BaudRateComboBox
        '
        Me.BaudRateComboBox.FormattingEnabled = True
        Me.BaudRateComboBox.Location = New System.Drawing.Point(155, 12)
        Me.BaudRateComboBox.Name = "BaudRateComboBox"
        Me.BaudRateComboBox.Size = New System.Drawing.Size(121, 21)
        Me.BaudRateComboBox.TabIndex = 6
        '
        'modeComboBox
        '
        Me.modeComboBox.FormattingEnabled = True
        Me.modeComboBox.Location = New System.Drawing.Point(155, 76)
        Me.modeComboBox.Name = "modeComboBox"
        Me.modeComboBox.Size = New System.Drawing.Size(121, 21)
        Me.modeComboBox.TabIndex = 7
        '
        'formatComboBox
        '
        Me.formatComboBox.FormattingEnabled = True
        Me.formatComboBox.Location = New System.Drawing.Point(155, 137)
        Me.formatComboBox.Name = "formatComboBox"
        Me.formatComboBox.Size = New System.Drawing.Size(121, 21)
        Me.formatComboBox.TabIndex = 8
        '
        'typeComboBox
        '
        Me.typeComboBox.FormattingEnabled = True
        Me.typeComboBox.Location = New System.Drawing.Point(135, 252)
        Me.typeComboBox.Name = "typeComboBox"
        Me.typeComboBox.Size = New System.Drawing.Size(121, 21)
        Me.typeComboBox.TabIndex = 9
        '
        'OpenDeviceBtn
        '
        Me.OpenDeviceBtn.Location = New System.Drawing.Point(12, 360)
        Me.OpenDeviceBtn.Name = "OpenDeviceBtn"
        Me.OpenDeviceBtn.Size = New System.Drawing.Size(75, 23)
        Me.OpenDeviceBtn.TabIndex = 10
        Me.OpenDeviceBtn.Text = "Button1"
        Me.OpenDeviceBtn.UseVisualStyleBackColor = True
        '
        'DelayedSendBtn
        '
        Me.DelayedSendBtn.Location = New System.Drawing.Point(12, 406)
        Me.DelayedSendBtn.Name = "DelayedSendBtn"
        Me.DelayedSendBtn.Size = New System.Drawing.Size(75, 23)
        Me.DelayedSendBtn.TabIndex = 11
        Me.DelayedSendBtn.Text = "Button1"
        Me.DelayedSendBtn.UseVisualStyleBackColor = True
        '
        'deviceComboBox
        '
        Me.deviceComboBox.FormattingEnabled = True
        Me.deviceComboBox.Location = New System.Drawing.Point(155, 330)
        Me.deviceComboBox.Name = "deviceComboBox"
        Me.deviceComboBox.Size = New System.Drawing.Size(121, 21)
        Me.deviceComboBox.TabIndex = 12
        '
        'IDAutoIncCheckBox
        '
        Me.IDAutoIncCheckBox.AutoSize = True
        Me.IDAutoIncCheckBox.Location = New System.Drawing.Point(299, 16)
        Me.IDAutoIncCheckBox.Name = "IDAutoIncCheckBox"
        Me.IDAutoIncCheckBox.Size = New System.Drawing.Size(81, 17)
        Me.IDAutoIncCheckBox.TabIndex = 13
        Me.IDAutoIncCheckBox.Text = "CheckBox1"
        Me.IDAutoIncCheckBox.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(461, 609)
        Me.Controls.Add(Me.IDAutoIncCheckBox)
        Me.Controls.Add(Me.deviceComboBox)
        Me.Controls.Add(Me.DelayedSendBtn)
        Me.Controls.Add(Me.OpenDeviceBtn)
        Me.Controls.Add(Me.typeComboBox)
        Me.Controls.Add(Me.formatComboBox)
        Me.Controls.Add(Me.modeComboBox)
        Me.Controls.Add(Me.BaudRateComboBox)
        Me.Controls.Add(Me.DataTextBox)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.FrameIdTextBox)
        Me.Controls.Add(Me.SendIntervalTextBox)
        Me.Controls.Add(Me.numbersendTextBox)
        Me.Controls.Add(Me.ListView)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListView As System.Windows.Forms.ListView
    Friend WithEvents numbersendTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SendIntervalTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FrameIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents DataTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BaudRateComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents modeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents formatComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents typeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents OpenDeviceBtn As System.Windows.Forms.Button
    Friend WithEvents DelayedSendBtn As System.Windows.Forms.Button
    Friend WithEvents deviceComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents IDAutoIncCheckBox As System.Windows.Forms.CheckBox

End Class
