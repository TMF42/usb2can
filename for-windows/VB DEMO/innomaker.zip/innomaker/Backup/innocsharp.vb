Imports NPOI.SS.UserModel
Imports NPOI.XSSF.UserModel
Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.Globalization
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Timers
Imports System.Windows.Forms
Imports Timer = System.Timers.Timer
Imports InnoMakerUsb2CanLib

Namespace InnoMakerUsb2Can
    Enum FrameFormat
        FrameFormatStandard = 0
    End Enum

    Enum FrameType
        FrameTypeData = 0
    End Enum

    Enum CanMode
        CanModeNormal = 0
    End Enum

    Enum CheckIDType
        CheckIDTypeNone = 0
        CheckIDTypeIncrease = 1
    End Enum

    Enum CheckDataType
        CheckDataTypeNone = 0
        CheckDataTypeIncrease = 1
    End Enum

    Enum CheckErrorFrame
        CheckErrorFrameClose = 0
        CheckErrorFrameOpen = 1
    End Enum

    Enum SystemLanguage
        DefaultLanguage = 0
        EnglishLanguage = 1
        ChineseLanguage = 2
    End Enum

    Public Partial Class InnoMakerusb2Can
        Inherits Form

        Shared innomaker_MAX_TX_URBS As UInteger = 10

        Class innomaker_tx_context
            Public echo_id As UInt32
        End Class

        Class innomaker_can
            Public tx_ctx_lock As SpinLock
            Public tx_context As innomaker_tx_context()
        End Class

        Private checkIdType As CheckIDType
        Private checkDataType As CheckDataType
        Private checkErrorFrame As CheckErrorFrame
        Private currentLanguage As SystemLanguage
        Private usbIO As UsbCan
        Private currentDeivce As InnoMakerDevice
        Private delayedSendFrameId As String = ""
        Private delayedSendFrameData As String = ""
        Private numberSended As UInt16 = 0
        Private can As innomaker_can
        Private bitrateIndexes As String() = {"20K", "33.33K", "40K", "50K", "66.66K", "80K", "83.33K", "100K", "125K", "200K", "250K", "400K", "500K", "666K", "800K", "1000K"}
        Private workModeInexes As String() = {"Normal", "LoopBack", "ListenOnly"}
        Private frameFormatIndexes As String() = {"Data Frame"}
        Private frameTypeIndexes As String() = {"Standard"}
        Private curBitrateSelectIndex As Integer
        Private curWorkModeSelectIndex As Integer
        Private sendTimer As Timer
        Private recvTimer As Timer
        Delegate Sub updateListViewDelegate(ByVal inputBytes As Byte())
        Delegate Sub updateSendBtnDelegate(ByVal tag As Integer)

        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub InnoMakerusb2Can_Load(ByVal sender As Object, ByVal e As EventArgs)
            usbIO = New UsbCan()
            usbIO.removeDeviceDelegate = AddressOf Me.RemoveDeviceNotifyDelegate
            usbIO.addDeviceDelegate = AddressOf Me.AddDeviceNotifyDelegate
            can = New innomaker_can()
            can.tx_context = New innomaker_tx_context(innomaker_MAX_TX_URBS - 1) {}
            checkIdType = CheckIDType.CheckIDTypeNone
            checkErrorFrame = CheckErrorFrame.CheckErrorFrameClose
            Form1.numbersendTextBox.Text = "1"
            Form1.SendIntervalTextBox.Text = "1000"
            curBitrateSelectIndex = -1
            curWorkModeSelectIndex = -1
            Form1.FrameIdTextBox.Text = "00 00 00 00"
            'Form1.FrameIdTextBox.PlaceHolderText = "Please Input Four Bytes Hex"
            Form1.DataTextBox.Text = "00 00 00 00 00 00 00 00"
            'Form1.DataTextBox.PlaceHolderText = "Please Input Eight Bytes Hex"
            Form1.BaudRateComboBox.DataSource = bitrateIndexes
            Form1.modeComboBox.DataSource = workModeInexes
            Form1.formatComboBox.DataSource = frameFormatIndexes
            Form1.typeComboBox.DataSource = frameTypeIndexes
            Form1.formatComboBox.Enabled = False
            Form1.typeComboBox.Enabled = False
            Form1.OpenDeviceBtn.Tag = 0
            Form1.DelayedSendBtn.Tag = 0
            Dim Columns As String() = {"SeqID", "SystemTime", "Channel", "Direction", "FrameId", "FrameType", "FrameFormat", "Length", "FrameData"}
            Dim ColumnWidths As Integer() = {60, 120, 60, 60, 120, 60, 60, 60, 200}

            For i As Integer = 0 To Columns.Length - 1
                Dim ch As ColumnHeader = New ColumnHeader()
                ch.Text = Columns(i)
                ch.Width = ColumnWidths(i)
                ch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
                Form1.ListView.Columns.Add(ch)
            Next

            Dim lan As String = Properties.Settings.[Default].Language

            If lan = "English" Then
                currentLanguage = SystemLanguage.EnglishLanguage
                'LangCombox.Text = "English"
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo("en-US")
                ApplyResources()
            Else
                currentLanguage = SystemLanguage.ChineseLanguage
                'LangCombox.Text = "Chinese"
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo("zh-Hans")
                ApplyResources()
            End If
        End Sub

        Private Sub DeviceComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
            currentDeivce = usbIO.getInnoMakerDevice(DeviceComboBox.SelectedIndex)
        End Sub

        Private Sub ScanDeviceBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            usbIO.closeInnoMakerDevice(currentDeivce)
            currentDeivce = Nothing
            Form1.DeviceComboBox.Text = ""
            usbIO.scanInnoMakerDevices()
            UpdateDevices()
        End Sub

        Private Sub OpenDeviceBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            If Form1.OpenDeviceBtn.Tag.Equals(1) Then
                _closeDevice()
            Else
                _openDevice()
            End If
        End Sub

        Private Sub ModeComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
            curWorkModeSelectIndex = Form1.modeComboBox.SelectedIndex
        End Sub

        Private Sub BaudRateComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
            curBitrateSelectIndex = Form1.BaudRateComboBox.SelectedIndex
        End Sub

        Private Sub DelayedSendBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            If Form1.DelayedSendBtn.Tag.Equals(1) Then
                cancelSendTimer()

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    Form1.DelayedSendBtn.Text = "定时发送"
                Else
                    Form1.DelayedSendBtn.Text = "Delayed Send"
                End If

                Form1.DelayedSendBtn.Tag = 0
            Else
                cancelSendTimer()
                setupSendTimer()
            End If
        End Sub

        Private Sub SendBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            Dim frameId As String = Form1.FrameIdTextBox.Text
            Dim frameData As String = Form1.DataTextBox.Text

            If currentDeivce Is Nothing OrElse currentDeivce.isOpen = False Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("设备未打开")
                Else
                    MessageBox.Show("Device Not Open")
                End If

                Return
            End If

            If curBitrateSelectIndex = -1 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("波特率不正确")
                Else
                    MessageBox.Show("BaudRate Not Right")
                End If

                Return
            End If

            If curWorkModeSelectIndex = -1 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("设备模式不正确")
                Else
                    MessageBox.Show("Work Mode Not Right")
                End If

                Return
            End If

            If frameId.Length = 0 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("帧ID不正确")
                Else
                    MessageBox.Show("Frame ID Not Right")
                End If

                Return
            End If

            If frameData.Length = 0 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("帧数据不正确")
                Else
                    MessageBox.Show("Frame Data Not Right")
                End If

                Return
            End If

            Dim txc As innomaker_tx_context = innomaker_alloc_tx_context(can)

            If txc.echo_id = &HfF Then
                Return
            End If

            Dim standardFrameData As Byte() = buildStandardFrame(frameId, frameData, txc.echo_id)
            Dim result As Boolean = usbIO.sendInnoMakerDeviceBuf(currentDeivce, standardFrameData, standardFrameData.Length)

            If result Then
                Console.WriteLine("SEND:" & getHexString(standardFrameData))
            Else
            End If
        End Sub

        Public Shared Function getHexString(ByVal b As Byte()) As String
            Dim hex As String = ""

            For i As Integer = 0 To b.Length - 1
                hex += (b(i) And &HFF).ToString("X2")

                If hex.Length = 1 Then
                    hex = "0"c & hex
                End If

                hex += " "
            Next

            Return "0x|" & hex.ToUpper()
        End Function

        Private Sub ClearBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            Form1.ListView.Items.Clear()
        End Sub

        Public Sub ExportExcel(ByVal lv As ListView)
            If lv.Items Is Nothing Then Return
            Dim saveFileName As String = ""
            Dim saveDialog As SaveFileDialog = New SaveFileDialog()
            saveDialog.DefaultExt = "xls"
            saveDialog.Filter = "Excel File|*.xls"
            saveDialog.FileName = DateTime.Now.ToString("yyyy-MM-dd")
            saveDialog.ShowDialog()
            saveFileName = saveDialog.FileName
            If saveFileName.IndexOf(":") < 0 Then Return
            If File.Exists(saveFileName) Then File.Delete(saveFileName)
            DoExport(Form1.ListView, saveFileName)
        End Sub

        Private Sub ExportBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            ExportExcel(Form1.ListView)
        End Sub

        Private Sub IDAutoIncCheckBox_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
            checkIdType = If(Form1.IDAutoIncCheckBox.Checked, checkIdType.CheckIDTypeIncrease, checkIdType.CheckIDTypeNone)
        End Sub

        Private Sub DataAutoIncCheckBox_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
            checkDataType = If(Form1.DataAutoIncCheckBox.Checked, checkDataType.CheckDataTypeIncrease, checkDataType.CheckDataTypeNone)
        End Sub

        Private Sub HideErrorFrameCheckBox_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
            checkErrorFrame = If(Form1.hideErrorFrameCheckBox.Checked, checkErrorFrame.CheckErrorFrameOpen, checkErrorFrame.CheckErrorFrameClose)
        End Sub

        Private Sub _openDevice()
            If currentDeivce Is Nothing Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("设备未打开，请选择设备")
                Else
                    MessageBox.Show("Device not open, Please select device")
                End If

                Return
            End If

            If curBitrateSelectIndex = -1 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("波特率不正确")
                Else
                    MessageBox.Show("Baudrate not right")
                End If

                Return
            End If

            Dim usbCanMode As UsbCan.UsbCanMode = UsbCan.UsbCanMode.UsbCanModeNormal

            If curWorkModeSelectIndex = 0 Then
                usbCanMode = UsbCan.UsbCanMode.UsbCanModeNormal
            ElseIf curWorkModeSelectIndex = 1 Then
                usbCanMode = UsbCan.UsbCanMode.UsbCanModeLoopback
            ElseIf curWorkModeSelectIndex = 2 Then
                usbCanMode = UsbCan.UsbCanMode.UsbCanModeListenOnly
            End If

            Dim deviceBittming As UsbCan.innomaker_device_bittming = GetBittming(BaudRateComboBox.SelectedIndex)
            Dim result As Boolean = usbIO.UrbSetupDevice(currentDeivce, usbCanMode, deviceBittming)

            If Not result Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("打开设备失败，请重新选择或扫描设备再打开!，若还不行，重新插拔")
                Else
                    MessageBox.Show("Open Device Fail, Please Reselect Or Scan Device and Open, If alse fail, replug in device")
                End If

                Return
            End If

            For i As Integer = 0 To innomaker_MAX_TX_URBS - 1
                can.tx_context(i) = New innomaker_tx_context()
                can.tx_context(i).echo_id = innomaker_MAX_TX_URBS
            Next

            setupRecvTimer()
            OpenDeviceBtn.Tag = 1

            If currentLanguage = SystemLanguage.ChineseLanguage Then
                OpenDeviceBtn.Text = "关闭设备"
            Else
                OpenDeviceBtn.Text = "Close Device"
            End If

            BaudRateComboBox.Enabled = False
            DeviceComboBox.Enabled = False
            ModeComboBox.Enabled = False
            ScanDeviceBtn.Enabled = False
        End Sub

        Private Sub _closeDevice()
            cancelRecvTimer()
            cancelSendTimer()
            Thread.Sleep(100)

            If currentDeivce IsNot Nothing AndAlso currentDeivce.isOpen = True Then
                usbIO.UrbResetDevice(currentDeivce)
                usbIO.closeInnoMakerDevice(currentDeivce)

                For i As Integer = 0 To innomaker_MAX_TX_URBS - 1
                    can.tx_context(i).echo_id = innomaker_MAX_TX_URBS
                Next
            End If

            BaudRateComboBox.Enabled = True
            DeviceComboBox.Enabled = True
            ScanDeviceBtn.Enabled = True
            ModeComboBox.Enabled = True
            OpenDeviceBtn.Tag = 0

            If currentLanguage = SystemLanguage.ChineseLanguage Then
                OpenDeviceBtn.Text = "打开设备"
            Else
                OpenDeviceBtn.Text = "Open Device"
            End If

            DelayedSendBtn.Tag = 0

            If currentLanguage = SystemLanguage.ChineseLanguage Then
                DelayedSendBtn.Text = "定时发送"
            Else
                DelayedSendBtn.Text = "Delayed Send"
            End If
        End Sub

        Private Function GetBittming(ByVal index As Integer) As UsbCan.innomaker_device_bittming
            Dim bittming As UsbCan.innomaker_device_bittming

            Select Case index
                Case 0
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 150
                Case 1
                    bittming.prop_seg = 3
                    bittming.phase_seg1 = 3
                    bittming.phase_seg2 = 1
                    bittming.sjw = 1
                    bittming.brp = 180
                Case 2
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 75
                Case 3
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 60
                Case 4
                    bittming.prop_seg = 3
                    bittming.phase_seg1 = 3
                    bittming.phase_seg2 = 1
                    bittming.sjw = 1
                    bittming.brp = 90
                Case 5
                    bittming.prop_seg = 3
                    bittming.phase_seg1 = 3
                    bittming.phase_seg2 = 1
                    bittming.sjw = 1
                    bittming.brp = 75
                Case 6
                    bittming.prop_seg = 3
                    bittming.phase_seg1 = 3
                    bittming.phase_seg2 = 1
                    bittming.sjw = 1
                    bittming.brp = 72
                Case 7
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 30
                Case 8
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 24
                Case 9
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 15
                Case 10
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 12
                Case 11
                    bittming.prop_seg = 3
                    bittming.phase_seg1 = 3
                    bittming.phase_seg2 = 1
                    bittming.sjw = 1
                    bittming.brp = 15
                Case 12
                    bittming.prop_seg = 6
                    bittming.phase_seg1 = 7
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 6
                Case 13
                    bittming.prop_seg = 3
                    bittming.phase_seg1 = 3
                    bittming.phase_seg2 = 2
                    bittming.sjw = 1
                    bittming.brp = 8
                Case 14
                    bittming.prop_seg = 7
                    bittming.phase_seg1 = 8
                    bittming.phase_seg2 = 4
                    bittming.sjw = 1
                    bittming.brp = 3
                Case 15
                    bittming.prop_seg = 5
                    bittming.phase_seg1 = 6
                    bittming.phase_seg2 = 4
                    bittming.sjw = 1
                    bittming.brp = 3
                Case Else
                    bittming.prop_seg = 5
                    bittming.phase_seg1 = 6
                    bittming.phase_seg2 = 4
                    bittming.sjw = 1
                    bittming.brp = 3
            End Select

            Return bittming
        End Function

        Private Sub AddDeviceNotifyDelegate()
            If currentDeivce IsNot Nothing Then
                _closeDevice()
                DeviceComboBox.Text = ""
                currentDeivce = Nothing
            End If

            usbIO.scanInnoMakerDevices()
            UpdateDevices()
        End Sub

        Private Sub RemoveDeviceNotifyDelegate()
            If currentDeivce IsNot Nothing Then
                _closeDevice()
                DeviceComboBox.Text = ""
                currentDeivce = Nothing
            End If

            usbIO.scanInnoMakerDevices()
            UpdateDevices()
        End Sub

        Private Sub UpdateDevices()
            Dim devIndexes As List(Of String) = New List(Of String)()

            For i As Integer = 0 To usbIO.getInnoMakerDeviceCount() - 1
                Dim device As InnoMakerDevice = usbIO.getInnoMakerDevice(i)
                devIndexes.Add(device.deviceId.ToString())
            Next

            Form1.deviceComboBox.DataSource = devIndexes
        End Sub

        Private Function buildStandardFrame(ByVal frameId As String, ByVal frameData As String, ByVal echoId As UInteger) As Byte()
            Dim frame As UsbCan.innomaker_host_frame
            frame.data = New Byte(7) {}
            frame.echo_id = echoId
            frame.can_dlc = 8
            frame.channel = 0
            frame.flags = 0
            frame.reserved = 0
            frameId = Formatter.formatStringToHex(frameId, 8, True)
            frameData = Formatter.formatStringToHex(frameData, 16, True)
            Dim canIdArr As String() = frameId.Split(" "c)
            Dim canId As Byte() = {&H00, &H00, &H00, &H00}

            For i As Integer = 0 To canIdArr.Length - 1
                Dim b As String = canIdArr(canIdArr.Length - i - 1)
                canId(i) = CByte(Convert.ToInt32(b, 16))
            Next

            frame.can_id = System.BitConverter.ToUInt32(canId, 0)
            Dim dataByte As String() = frameData.Split(" "c)

            For i As Integer = 0 To dataByte.Length - 1
                Dim byteValue As String = dataByte(i)
                frame.data(i) = CByte(Convert.ToInt32(byteValue, 16))
            Next

            Return StructureHelper.StructToBytes(frame)
        End Function

        Private Sub setupSendTimer()
            Dim interval As Integer = Integer.Parse(SendIntervalTextBox.Text)

            If interval < 100 OrElse interval > 5000 Then
                Return
            End If

            If Integer.Parse(Form1.numbersendTextBox.Text) < 1 OrElse Integer.Parse(NumberSendTextBox.Text) > 10000 Then
                Return
            End If

            Dim frameId As String = Form1.FrameIdTextBox.Text
            Dim frameData As String = Form1.DataTextBox.Text

            If currentDeivce Is Nothing OrElse currentDeivce.isOpen = False Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("设备未打开")
                Else
                    MessageBox.Show("Device Not Open")
                End If

                Return
            End If

            If curBitrateSelectIndex = -1 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("波特率不正确")
                Else
                    MessageBox.Show("BaudRate Not Right")
                End If

                Return
            End If

            If curWorkModeSelectIndex = -1 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("设备模式不正确")
                Else
                    MessageBox.Show("Work Mode Not Right")
                End If

                Return
            End If

            If frameId.Length = 0 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("帧ID不正确")
                Else
                    MessageBox.Show("Frame ID Not Right")
                End If

                Return
            End If

            If frameData.Length = 0 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    MessageBox.Show("帧数据不正确")
                Else
                    MessageBox.Show("Frame Data Not Right")
                End If

                Return
            End If

            sendTimer = New Timer(interval)
            numberSended = 0
            AddHandler sendTimer.Elapsed, New ElapsedEventHandler(AddressOf sendToDev)
            sendTimer.AutoReset = True
            sendTimer.Enabled = True
            updateSendBtn(1)
        End Sub

        Private Sub sendToDev(ByVal source As Object, ByVal e As System.Timers.ElapsedEventArgs)
            If delayedSendFrameId.Length = 0 Then
                delayedSendFrameId = Form1.FrameIdTextBox.Text
            End If

            If delayedSendFrameData.Length = 0 Then
                delayedSendFrameData = Form1.DataTextBox.Text
            End If

            If delayedSendFrameId.Length = 0 Then
                cancelSendTimer()

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    Form1.DelayedSendBtn.Text = "定时发送"
                    MessageBox.Show("帧ID不正确")
                Else
                    Form1.DelayedSendBtn.Text = "Delayed Send"
                    MessageBox.Show("Frame ID Not Right")
                End If

                Form1.DelayedSendBtn.Tag = 0
                Return
            End If

            If delayedSendFrameData.Length = 0 Then
                cancelSendTimer()

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    Form1.DelayedSendBtn.Text = "定时发送"
                    MessageBox.Show("帧数据不正确")
                Else
                    Form1.DelayedSendBtn.Text = "Delayed Send"
                    MessageBox.Show("Frame Data Not Right")
                End If

                Form1.DelayedSendBtn.Tag = 0
                Return
            End If

            Dim txc As innomaker_tx_context = innomaker_alloc_tx_context(can)

            If txc.echo_id = &HfF Then
                Return
            End If

            Dim standardFrameData As Byte() = buildStandardFrame(delayedSendFrameId, delayedSendFrameData, txc.echo_id)
            Dim result As Boolean = usbIO.sendInnoMakerDeviceBuf(currentDeivce, standardFrameData, standardFrameData.Length)

            If result Then
                Console.WriteLine("SEND:" & getHexString(standardFrameData))
            End If

            If checkIdType = CheckIDType.CheckIDTypeNone Then
            Else
                delayedSendFrameId = increaseFrameIdHexString(delayedSendFrameId, 8)
            End If

            If checkDataType = CheckDataType.CheckDataTypeNone Then
            Else
                delayedSendFrameData = increaseFrameIdHexString(delayedSendFrameData, 16)
            End If

            If System.Threading.Interlocked.Increment(numberSended) = Integer.Parse(NumberSendTextBox.Text) Then
                cancelSendTimer()
                Dim d As updateSendBtnDelegate = New updateSendBtnDelegate(AddressOf updateSendBtn)
                Me.Invoke(d, 0)
            End If
        End Sub

        Private Function increaseFrameIdHexString(ByVal frameId As String, ByVal bit As Integer) As String
            Dim increaseFrameId As String = ""
            frameId = Formatter.formatStringToHex(frameId, bit, True)
            Dim dataByte As String() = frameId.Split(" "c)
            Dim frameIdBytes As Byte() = New Byte(dataByte.Length - 1) {}
            Dim increaseBit As Boolean = True

            For i As Integer = dataByte.Length - 1 To 0
                Dim byteValue As String = dataByte(i)
                frameIdBytes(i) = Convert.ToByte(byteValue, 16)

                If increaseBit Then

                    If frameIdBytes(i) + 1 > &HfF Then
                        frameIdBytes(i) = &H00
                        increaseBit = True
                    Else
                        frameIdBytes(i) = CByte((frameIdBytes(i) + 1))
                        increaseBit = False
                    End If
                End If
            Next

            For i As Integer = 0 To dataByte.Length - 1
                increaseFrameId += frameIdBytes(i).ToString("X2")

                If i <> dataByte.Length - 1 Then
                    increaseFrameId += " "c
                End If
            Next

            Return increaseFrameId
        End Function

        Private Sub setupRecvTimer()
            recvTimer = New Timer(30)
            AddHandler recvTimer.Elapsed, New ElapsedEventHandler(AddressOf inputFromDev)
            recvTimer.AutoReset = True
            recvTimer.Enabled = True
        End Sub

        Private Sub inputFromDev(ByVal source As Object, ByVal e As System.Timers.ElapsedEventArgs)
            If currentDeivce Is Nothing OrElse currentDeivce.isOpen = False Then
                cancelRecvTimer()
                Return
            End If

            Dim frame As UsbCan.innomaker_host_frame = New UsbCan.innomaker_host_frame()
            Dim size As Integer = Marshal.SizeOf(frame)
            Dim inputBytes As Byte() = New Byte(size - 1) {}
            Dim result As Boolean = usbIO.getInnoMakerDeviceBuf(currentDeivce, inputBytes, size)

            If result Then
                Dim d As updateListViewDelegate = New updateListViewDelegate(AddressOf updateUI)
                Me.Invoke(d, inputBytes)
            End If
        End Sub

        Private Sub updateSendBtn(ByVal tag As Integer)
            If tag = 0 Then

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    DelayedSendBtn.Text = "定时发送"
                Else
                    DelayedSendBtn.Text = "Delayed Send"
                End If

                Form1.DelayedSendBtn.Tag = 0
            Else

                If currentLanguage = SystemLanguage.ChineseLanguage Then
                    Form1.DelayedSendBtn.Text = "停止"
                Else
                    Form1.DelayedSendBtn.Text = "Stop"
                End If

                Form1.DelayedSendBtn.Tag = 1
            End If
        End Sub

        Private Sub updateUI(ByVal inputBytes As Byte())
            Dim echoIdBytes As Byte() = New Byte(3) {}
            echoIdBytes(0) = inputBytes(0)
            echoIdBytes(1) = inputBytes(1)
            echoIdBytes(2) = inputBytes(2)
            echoIdBytes(3) = inputBytes(3)
            Dim echoId As UInt32 = BitConverter.ToUInt32(echoIdBytes, 0)
            Dim frameIdBytes As Byte() = New Byte(3) {}
            frameIdBytes(0) = inputBytes(4)
            frameIdBytes(1) = inputBytes(5)
            frameIdBytes(2) = inputBytes(6)
            frameIdBytes(3) = inputBytes(7)
            Dim frameId As UInt32 = BitConverter.ToUInt32(frameIdBytes, 0)
            Dim frameDataBytes As Byte() = New Byte(7) {}
            Buffer.BlockCopy(inputBytes, 12, frameDataBytes, 0, 8)
            Dim seqStr As String = Form1.ListView.Items.Count.ToString()
            Dim systemTimeStr As String = DateTime.Now.ToString()
            Dim channelStr As String = "0"
            Dim directionStr As String = If(echoId = &HfffffffF, "Recv", "Send")
            Dim frameIdStr As String = "0x" & frameId.ToString("X2")
            Dim frameTypeStr As String = "Data Frame"
            Dim frameFormatStr As String = "Standard Frame"
            Dim frameLengthStr As String = "8"
            Dim frameDataStr As String = getHexString(frameDataBytes)

            If currentLanguage = SystemLanguage.ChineseLanguage Then
                directionStr = If(echoId = &HfffffffF, "接受", "发送")
                frameTypeStr = "数据帧"
                frameFormatStr = "标准帧"
            End If

            If echoId = &HfffffffF Then

                If (frameId And &H00000020) = &H20000000 AndAlso checkErrorFrame = CheckErrorFrame.CheckErrorFrameOpen Then
                    Return
                End If

                Dim lvi As ListViewItem = New ListViewItem()
                lvi.Text = Form1.ListView.Items.Count.ToString()
                lvi.ForeColor = If(((frameId And &H20000000) = &H20000000), Color.Red, Color.Black)
                lvi.SubItems.Add(systemTimeStr)
                lvi.SubItems.Add(channelStr)
                lvi.SubItems.Add(directionStr)
                lvi.SubItems.Add(frameIdStr)
                lvi.SubItems.Add(frameTypeStr)
                lvi.SubItems.Add(frameFormatStr)
                lvi.SubItems.Add(frameLengthStr)
                lvi.SubItems.Add(frameDataStr)
                Form1.ListView.BeginUpdate()
                Form1.ListView.Items.Add(lvi)
                Form1.ListView.EndUpdate()
                Form1.ListView.Items(Form1.ListView.Items.Count - 1).EnsureVisible()
            Else
                Dim txc As innomaker_tx_context = innomaker_get_tx_context(can, echoId)

                If txc.echo_id = &HfF Then
                    Return
                End If

                Dim lvi As ListViewItem = New ListViewItem()
                lvi.ForeColor = Color.Green
                lvi.Text = Form1.ListView.Items.Count.ToString()
                lvi.SubItems.Add(systemTimeStr)
                lvi.SubItems.Add(channelStr)
                lvi.SubItems.Add(directionStr)
                lvi.SubItems.Add(frameIdStr)
                lvi.SubItems.Add(frameTypeStr)
                lvi.SubItems.Add(frameFormatStr)
                lvi.SubItems.Add(frameLengthStr)
                lvi.SubItems.Add(frameDataStr)
                Form1.ListView.BeginUpdate()
                Form1.ListView.Items.Add(lvi)
                Form1.ListView.EndUpdate()
                Form1.ListView.Items(Form1.ListView.Items.Count - 1).EnsureVisible()
                innomaker_free_tx_context(txc)
            End If
        End Sub

        Private Sub cancelRecvTimer()
            If recvTimer IsNot Nothing Then
                recvTimer.Enabled = False
                recvTimer.[Stop]()
                recvTimer = Nothing
            End If
        End Sub

        Private Sub cancelSendTimer()
            If sendTimer IsNot Nothing Then
                sendTimer.Enabled = False
                sendTimer.[Stop]()
                sendTimer = Nothing
            End If

            delayedSendFrameId = ""
            delayedSendFrameData = ""
            numberSended = 0
        End Sub

        Private Sub DoExport(ByVal listView As ListView, ByVal strFileName As String)
            Dim rowNum As Integer = listView.Items.Count
            Dim columnNum As Integer = listView.Items(0).SubItems.Count
            Dim columnIndex As Integer = 0

            If rowNum = 0 OrElse String.IsNullOrEmpty(strFileName) Then
                Return
            End If

            If rowNum > 0 Then
                Dim workBook As XSSFWorkbook = New XSSFWorkbook()
                Dim sheet As XSSFSheet = CType(workBook.CreateSheet(), XSSFSheet)
                Dim frow0 As IRow = sheet.CreateRow(0)

                For Each dc As ColumnHeader In listView.Columns
                    frow0.CreateCell(columnIndex).SetCellValue(dc.Text)
                    columnIndex += 1
                Next

                For i As Integer = 0 To rowNum - 1
                    Dim frow1 As IRow = sheet.CreateRow(i + 1)

                    For j As Integer = 0 To columnNum - 1
                        frow1.CreateCell(j).SetCellValue(listView.Items(i).SubItems(j).Text)
                    Next
                Next

                Try

                    Using fs As FileStream = New FileStream(strFileName, FileMode.Create, FileAccess.Write)
                        workBook.Write(fs)
                        workBook.Close()
                    End Using

                    If currentLanguage = SystemLanguage.ChineseLanguage Then
                        MessageBox.Show("导出成功")
                    Else
                        MessageBox.Show("Export Success")
                    End If

                Catch __unusedException1__ As Exception
                    workBook.Close()
                End Try
            End If
        End Sub

        Private Shared Function innomaker_alloc_tx_context(ByVal dev As innomaker_can) As innomaker_tx_context
            Dim _lock As Boolean = False
            dev.tx_ctx_lock.Enter(_lock)

            For i As UInteger = 0 To innomaker_MAX_TX_URBS - 1

                If dev.tx_context(i).echo_id = innomaker_MAX_TX_URBS Then
                    dev.tx_context(i).echo_id = i
                    Console.WriteLine("innomaker_alloc_tx_context" & i)
                    dev.tx_ctx_lock.[Exit]()
                    _lock = False
                    Return dev.tx_context(i)
                End If
            Next

            dev.tx_ctx_lock.[Exit]()
            _lock = False
            Dim nullContext As innomaker_tx_context = New innomaker_tx_context()
            nullContext.echo_id = &HfF
            Return nullContext
        End Function

        Private Shared Sub innomaker_free_tx_context(ByVal txc As innomaker_tx_context)
            Console.WriteLine("innomaker_free_tx_context" & txc.echo_id)
            txc.echo_id = innomaker_MAX_TX_URBS
        End Sub

        Private Function innomaker_get_tx_context(ByVal dev As innomaker_can, ByVal id As UInteger) As innomaker_tx_context
            If id < innomaker_MAX_TX_URBS Then
                Dim _lock As Boolean = False
                dev.tx_ctx_lock.Enter(_lock)

                If dev.tx_context(id).echo_id = id Then
                    dev.tx_ctx_lock.[Exit]()
                    _lock = False
                    Console.WriteLine("innomaker_get_tx_context" & id)
                    Return dev.tx_context(id)
                End If

                dev.tx_ctx_lock.[Exit]()
                _lock = False
            End If

            Dim nullContext As innomaker_tx_context = New innomaker_tx_context()
            nullContext.echo_id = &HfF
            Return nullContext
        End Function

        Private Sub numberSendKeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
            If Not Char.IsNumber(e.KeyChar) AndAlso e.KeyChar <> ChrW(8) Then
                e.Handled = True
            End If
        End Sub

        Private Sub sendIntervalKeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
            If Not Char.IsNumber(e.KeyChar) AndAlso e.KeyChar <> ChrW(8) Then
                e.Handled = True
            End If
        End Sub

        Private Sub FrameIdTextBox_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        End Sub

        Private Sub DataTextBox_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        End Sub

        Public Class StructureHelper
            Public Shared Function StructToBytes(ByVal structObj As Object) As Byte()
                Dim size As Integer = Marshal.SizeOf(structObj)
                Dim buffer As IntPtr = Marshal.AllocHGlobal(size)

                Try
                    Marshal.StructureToPtr(structObj, buffer, False)
                    Dim bytes As Byte() = New Byte(size - 1) {}
                    Marshal.Copy(buffer, bytes, 0, size)
                    Return bytes
                Finally
                    Marshal.FreeHGlobal(buffer)
                End Try
            End Function

            Public Shared Function ByteToStruct(ByVal bytes As Byte(), ByVal type As Type) As Object
                Dim size As Integer = Marshal.SizeOf(type)

                If size > bytes.Length Then
                    Return Nothing
                End If

                Dim structPtr As IntPtr = Marshal.AllocHGlobal(size)
                Marshal.Copy(bytes, 0, structPtr, size)
                Dim obj As Object = Marshal.PtrToStructure(structPtr, type)
                Marshal.FreeHGlobal(structPtr)
                Return obj
            End Function
        End Class

        Public Class Formatter
            Public Shared Function formatString(ByVal originString As String, ByVal charactersInString As String) As String
                Dim formatString As String = ""

                For Each c As Char In originString

                    If charactersInString.Contains(c.ToString()) Then
                        formatString += c
                    End If
                Next

                Return formatString
            End Function

            Private Shared Function dealWithString(ByVal str As String) As String
                Dim dealStr As String = ""
                Dim i As Integer = 0

                For Each c As Char In str

                    If System.Threading.Interlocked.Increment(i) = 3 Then
                        dealStr += " "
                        i = 1
                    End If

                    dealStr += c.ToString()
                Next

                Return dealStr
            End Function

            Public Shared Function formatStringToHex(ByVal originString As String, ByVal limitLength As Integer, ByVal padding As Boolean) As String
                If padding Then
                    originString = originString.Replace(" ", "")
                End If

                Dim str As String = formatString(originString, "0123456789ABCDEFabcdef")

                If str.Length > limitLength Then
                    str = str.Substring(0, limitLength)
                End If

                If str.Length = 0 Then
                    str = "00"
                End If

                If padding Then
                    str = dealWithString(str)
                End If

                Return str
            End Function

            Public Shared Sub adjustTextFieldToHex(ByVal textBox As TextBox, ByVal limitLength As Integer, ByVal padding As Boolean)
                Dim originString As String = textBox.Text

                If padding Then
                    originString = originString.Replace(" ", "")
                End If

                Dim str As String = formatString(originString, "0123456789ABCDEFabcdef")

                If str.Length > limitLength Then
                    str = str.Substring(0, limitLength)
                End If

                If padding Then
                    str = dealWithString(str)
                End If

                textBox.Text = str
            End Sub
        End Class

        Private Sub LangCombox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
            If LangCombox.SelectedIndex = 0 AndAlso Properties.Settings.[Default].Language <> "English" Then
                currentLanguage = SystemLanguage.EnglishLanguage
                Properties.Settings.[Default].Language = "English"
                Properties.Settings.[Default].Save()
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo("en-US")
                ApplyResources()
            ElseIf LangCombox.SelectedIndex = 1 AndAlso Properties.Settings.[Default].Language <> "Chinese" Then
                currentLanguage = SystemLanguage.ChineseLanguage
                Properties.Settings.[Default].Language = "Chinese"
                Properties.Settings.[Default].Save()
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo("zh-Hans")
                ApplyResources()
            End If
        End Sub

        Private Sub ApplyResources()
            Dim res As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(InnoMakerusb2Can))

            For Each ctl As Control In Controls
                res.ApplyResources(ctl, ctl.Name)
            Next

            Me.ResumeLayout(False)
            Me.PerformLayout()
            res.ApplyResources(Me, "$this")

            If currentLanguage = SystemLanguage.ChineseLanguage Then
                Dim Columns As String() = {"序号", "系统时间", "渠道", "方向", "帧ID", "帧类型", "帧格式", "长度", "帧数据"}

                For i As Integer = 0 To Columns.Length - 1
                    Form1.ListView.Columns(i).Text = Columns(i)
                Next

                'Form1.FrameIdTextBox.PlaceHolderText = "请输入4个16进制数字"
                'Form1.DataTextBox.PlaceHolderText = "请输入8个16进制数字"
            Else
                Dim Columns As String() = {"SeqID", "SystemTime", "Channel", "Direction", "FrameId", "FrameType", "FrameFormat", "Length", "FrameData"}

                For i As Integer = 0 To Columns.Length - 1
                    Form1.ListView.Columns(i).Text = Columns(i)
                Next

                FrameIdTextBox.PlaceHolderText = "Please Input Four Bytes Hex"
                DataTextBox.PlaceHolderText = "Please Input Eight Bytes Hex"
            End If
        End Sub

        Private Sub FrameIdMouseEnter(ByVal sender As Object, ByVal e As EventArgs)
            If currentLanguage = SystemLanguage.ChineseLanguage Then
                ' Me.toolTip1.Show("请输入4个16进制数字", FrameIdTextBox)
            Else
                ' Me.toolTip1.Show("Please input four hex number", FrameIdTextBox)
            End If
        End Sub

        Private Sub FrameIdMouseLeave(ByVal sender As Object, ByVal e As EventArgs)
            ' Me.toolTip1.Hide(Form1.FrameIdTextBox)
        End Sub

        Private Sub DateTextBoxMouseEnter(ByVal sender As Object, ByVal e As EventArgs)
            If currentLanguage = SystemLanguage.ChineseLanguage Then
                '  Me.toolTip1.Show("请输入8个16进制数字", DataTextBox)
            Else
                ' Me.toolTip1.Show("Please input eight hex number", DataTextBox)
            End If
        End Sub

        Private Sub DateTextBoxMouseLeave(ByVal sender As Object, ByVal e As EventArgs)
            'Me.toolTip1.Hide(Form1.DataTextBox)
        End Sub
    End Class
End Namespace
