﻿Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.Globalization
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Timers
Imports System.Windows.Forms
Imports Timer = System.Timers.Timer
Imports InnoMakerUsb2CanLib
Public Class Form1

    Private mycheckIdType As CheckIDType
    Private mycheckDataType As CheckDataType
    Private mycheckErrorFrame As CheckErrorFrame
    Private usbIO As UsbCan
    Private currentDeivce As InnoMakerDevice


    Enum FrameFormat
        FrameFormatStandard = 0
    End Enum

    Enum FrameType
        FrameTypeData = 0
    End Enum

    Enum CanMode
        CanModeNormal = 0
    End Enum

    Enum CheckIDType
        CheckIDTypeNone = 0
        CheckIDTypeIncrease = 1
    End Enum

    Enum CheckDataType
        CheckDataTypeNone = 0
        CheckDataTypeIncrease = 1
    End Enum

    Enum CheckErrorFrame
        CheckErrorFrameClose = 0
        CheckErrorFrameOpen = 1
    End Enum

    Enum SystemLanguage
        DefaultLanguage = 0
        EnglishLanguage = 1
        ChineseLanguage = 2
    End Enum


    Shared innomaker_MAX_TX_URBS As UInteger = 10


    Private delayedSendFrameId As String = ""
        Private delayedSendFrameData As String = ""
        Private numberSended As Integer = 0
        Private can As innomaker_can
        Private bitrateIndexes As String() = {"20K", "33.33K", "40K", "50K", "66.66K", "80K", "83.33K", "100K", "125K", "200K", "250K", "400K", "500K", "666K", "800K", "1000K"}
        Private workModeInexes As String() = {"Normal", "LoopBack", "ListenOnly"}
        Private frameFormatIndexes As String() = {"Data Frame"}
        Private frameTypeIndexes As String() = {"Standard"}
        Private curBitrateSelectIndex As Integer
        Private curWorkModeSelectIndex As Integer
        Private sendTimer As Timer
        Private recvTimer As Timer
        Delegate Sub updateListViewDelegate(ByVal inputBytes As Byte())
        Delegate Sub updateSendBtnDelegate(ByVal tag As Integer)




    Public Sub formatComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles formatComboBox.SelectedIndexChanged

    End Sub

    Private Sub scandeviceBtn_Click(sender As Object, e As EventArgs) Handles scandeviceBtn.Click
        Try

            usbIO.closeInnoMakerDevice(currentDeivce)


            currentDeivce = Nothing
            deviceComboBox.Text = ""
            usbIO.scanInnoMakerDevices()
            UpdateDevices()

        Catch

        End Try


    End Sub



    Public Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        usbIO = New UsbCan()
        usbIO.removeDeviceDelegate = AddressOf Me.RemoveDeviceNotifyDelegate
        usbIO.addDeviceDelegate = AddressOf Me.AddDeviceNotifyDelegate
        can = New innomaker_can()
        can.tx_context = New innomaker_tx_context(innomaker_MAX_TX_URBS - 1) {}
        mycheckIdType = CheckIDType.CheckIDTypeNone
        mycheckErrorFrame = CheckErrorFrame.CheckErrorFrameClose
        numbersendTextBox.Text = "1"
        SendIntervalTextBox.Text = "1000"
        curBitrateSelectIndex = -1
        curWorkModeSelectIndex = -1
        FrameIdTextBox.Text = "00 00 00 00"
        'FrameIdTextBox.PlaceHolderText = "Please Input Four Bytes Hex"
        DataTextBox.Text = "00 00 00 00 00 00 00 00"
        'DataTextBox.PlaceHolderText = "Please Input Eight Bytes Hex"
        BaudRateComboBox.DataSource = bitrateIndexes
        modeComboBox.DataSource = workModeInexes
        formatComboBox.DataSource = frameFormatIndexes
        typeComboBox.DataSource = frameTypeIndexes
        formatComboBox.Enabled = False
        typeComboBox.Enabled = False
        OpenDeviceBtn.Tag = 0
        DelayedSendBtn.Tag = 0

        Dim Columns As String() = {"SeqID", "SystemTime", "Channel", "Direction", "FrameId", "FrameType", "FrameFormat", "Length", "FrameData"}
        Dim ColumnWidths As Integer() = {60, 120, 60, 60, 120, 60, 60, 60, 200}

        For i As Integer = 0 To Columns.Length - 1
            Dim ch As ColumnHeader = New ColumnHeader()
            ch.Text = Columns(i)
            ch.Width = ColumnWidths(i)
            ch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            ListView1.Columns.Add(ch)
        Next

        BaudRateComboBox.SelectedIndex = 8
    End Sub

    Public Sub DeviceComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        currentDeivce = usbIO.getInnoMakerDevice(deviceComboBox.SelectedIndex)
    End Sub



    Public Sub OpenDeviceBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
        If OpenDeviceBtn.Tag.Equals(1) Then
            _closeDevice()
        Else
            _openDevice()
        End If
    End Sub



    Public Sub BaudRateComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        curBitrateSelectIndex = BaudRateComboBox.SelectedIndex
    End Sub

    Public Sub DelayedSendBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
        If DelayedSendBtn.Tag.Equals(1) Then
            cancelSendTimer()



            DelayedSendBtn.Tag = 0
        Else
            cancelSendTimer()
            setupSendTimer()
        End If
    End Sub

    Public Sub SendBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim frameId As String = FrameIdTextBox.Text
        Dim frameData As String = DataTextBox.Text

        If currentDeivce Is Nothing OrElse currentDeivce.isOpen = False Then



            Return
        End If

        If curBitrateSelectIndex = -1 Then


            Return
        End If

        If curWorkModeSelectIndex = -1 Then


            Return
        End If

        If frameId.Length = 0 Then



            Return
        End If

        If frameData.Length = 0 Then



            Return
        End If

        Dim txc As innomaker_tx_context = innomaker_alloc_tx_context(can)

        If txc.echo_id = &HFF Then
            Return
        End If

        Dim standardFrameData As Byte() = buildStandardFrame(frameId, frameData, txc.echo_id)
        Dim result As Boolean = usbIO.sendInnoMakerDeviceBuf(currentDeivce, standardFrameData, standardFrameData.Length)

        If result Then
            Console.WriteLine("SEND:" & getHexString(standardFrameData))
        Else
        End If
    End Sub

    Public Shared Function getHexString(ByVal b As Byte()) As String
        Dim hex As String = ""

        For i As Integer = 0 To b.Length - 1
            hex += (b(i) And &HFF).ToString("X2")

            If hex.Length = 1 Then
                hex = "0"c & hex
            End If

            hex += " "
        Next

        Return "0x|" & hex.ToUpper()
    End Function

    Public Sub ClearBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
        ListView1.Items.Clear()
    End Sub

    Public Sub ExportExcel(ByVal lv As ListView)
        If lv.Items Is Nothing Then Return
        Dim saveFileName As String = ""
        Dim saveDialog As SaveFileDialog = New SaveFileDialog()
        saveDialog.DefaultExt = "xls"
        saveDialog.Filter = "Excel File|*.xls"
        saveDialog.FileName = DateTime.Now.ToString("yyyy-MM-dd")
        saveDialog.ShowDialog()
        saveFileName = saveDialog.FileName
        If saveFileName.IndexOf(":") < 0 Then Return
        If File.Exists(saveFileName) Then File.Delete(saveFileName)
        DoExport(ListView1, saveFileName)
    End Sub

    Public Sub ExportBtn_Click(ByVal sender As Object, ByVal e As EventArgs)
        ExportExcel(ListView1)
    End Sub

    Public Sub IDAutoIncCheckBox_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
        mycheckIdType = If(IDAutoIncCheckBox.Checked, CheckIDType.CheckIDTypeIncrease, CheckIDType.CheckIDTypeNone)
    End Sub

    Public Sub DataAutoIncCheckBox_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
        mycheckDataType = If(DataAutoIncCheckBox.Checked, CheckDataType.CheckDataTypeIncrease, CheckDataType.CheckDataTypeNone)
    End Sub

    Public Sub HideErrorFrameCheckBox_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
        mycheckErrorFrame = If(hideErrorFrameCheckBox.Checked, CheckErrorFrame.CheckErrorFrameOpen, CheckErrorFrame.CheckErrorFrameClose)
    End Sub

    Public Sub _openDevice()
        If currentDeivce Is Nothing Then


            MessageBox.Show("Device not open, Please select device")

            Return
        End If

        If curBitrateSelectIndex = -1 Then


            MessageBox.Show("Baudrate not right")


            Return
        End If

        Dim usbCanMode As UsbCan.UsbCanMode = UsbCan.UsbCanMode.UsbCanModeNormal

        If curWorkModeSelectIndex = 0 Then
            usbCanMode = UsbCan.UsbCanMode.UsbCanModeNormal
        ElseIf curWorkModeSelectIndex = 1 Then
            usbCanMode = UsbCan.UsbCanMode.UsbCanModeLoopback
        ElseIf curWorkModeSelectIndex = 2 Then
            usbCanMode = UsbCan.UsbCanMode.UsbCanModeListenOnly
        End If

        Dim deviceBittming As UsbCan.innomaker_device_bittming = GetBittming(BaudRateComboBox.SelectedIndex)
        Dim result As Boolean = usbIO.UrbSetupDevice(currentDeivce, usbCanMode, deviceBittming)

        If Not result Then


            MessageBox.Show("Open Device Fail, Please Reselect Or Scan Device and Open, If alse fail, replug in device")


            Return
        End If

        For i As Integer = 0 To innomaker_MAX_TX_URBS - 1
            can.tx_context(i) = New innomaker_tx_context()
            can.tx_context(i).echo_id = innomaker_MAX_TX_URBS
        Next

        setupRecvTimer()
        OpenDeviceBtn.Tag = 1

        OpenDeviceBtn.Text = "Close Device"


        BaudRateComboBox.Enabled = False
        deviceComboBox.Enabled = False
        modeComboBox.Enabled = False
        scandeviceBtn.Enabled = False
    End Sub

    Public Sub _closeDevice()
        cancelRecvTimer()
        cancelSendTimer()
        Thread.Sleep(100)

        If currentDeivce IsNot Nothing AndAlso currentDeivce.isOpen = True Then
            usbIO.UrbResetDevice(currentDeivce)
            usbIO.closeInnoMakerDevice(currentDeivce)

            For i As Integer = 0 To innomaker_MAX_TX_URBS - 1
                can.tx_context(i).echo_id = innomaker_MAX_TX_URBS
            Next
        End If

        BaudRateComboBox.Enabled = True
        deviceComboBox.Enabled = True
        scandeviceBtn.Enabled = True
        modeComboBox.Enabled = True
        OpenDeviceBtn.Tag = 0


        OpenDeviceBtn.Text = "Open Device"


        DelayedSendBtn.Tag = 0

        DelayedSendBtn.Text = "Delayed Send"

    End Sub

    Private Function GetBittming(ByVal index As Integer) As UsbCan.innomaker_device_bittming
        Dim bittming As UsbCan.innomaker_device_bittming

        Select Case index
            Case 0
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 150
            Case 1
                bittming.prop_seg = 3
                bittming.phase_seg1 = 3
                bittming.phase_seg2 = 1
                bittming.sjw = 1
                bittming.brp = 180
            Case 2
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 75
            Case 3
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 60
            Case 4
                bittming.prop_seg = 3
                bittming.phase_seg1 = 3
                bittming.phase_seg2 = 1
                bittming.sjw = 1
                bittming.brp = 90
            Case 5
                bittming.prop_seg = 3
                bittming.phase_seg1 = 3
                bittming.phase_seg2 = 1
                bittming.sjw = 1
                bittming.brp = 75
            Case 6
                bittming.prop_seg = 3
                bittming.phase_seg1 = 3
                bittming.phase_seg2 = 1
                bittming.sjw = 1
                bittming.brp = 72
            Case 7
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 30
            Case 8
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 24
            Case 9
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 15
            Case 10
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 12
            Case 11
                bittming.prop_seg = 3
                bittming.phase_seg1 = 3
                bittming.phase_seg2 = 1
                bittming.sjw = 1
                bittming.brp = 15
            Case 12
                bittming.prop_seg = 6
                bittming.phase_seg1 = 7
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 6
            Case 13
                bittming.prop_seg = 3
                bittming.phase_seg1 = 3
                bittming.phase_seg2 = 2
                bittming.sjw = 1
                bittming.brp = 8
            Case 14
                bittming.prop_seg = 7
                bittming.phase_seg1 = 8
                bittming.phase_seg2 = 4
                bittming.sjw = 1
                bittming.brp = 3
            Case 15
                bittming.prop_seg = 5
                bittming.phase_seg1 = 6
                bittming.phase_seg2 = 4
                bittming.sjw = 1
                bittming.brp = 3
            Case Else
                bittming.prop_seg = 5
                bittming.phase_seg1 = 6
                bittming.phase_seg2 = 4
                bittming.sjw = 1
                bittming.brp = 3
        End Select

        Return bittming
    End Function

    Public Sub AddDeviceNotifyDelegate()
        If currentDeivce IsNot Nothing Then
            _closeDevice()
            deviceComboBox.Text = ""
            currentDeivce = Nothing
        End If

        usbIO.scanInnoMakerDevices()
        UpdateDevices()
    End Sub

    Public Sub RemoveDeviceNotifyDelegate()
        If currentDeivce IsNot Nothing Then
            _closeDevice()
            deviceComboBox.Text = ""
            currentDeivce = Nothing
        End If

        usbIO.scanInnoMakerDevices()
        UpdateDevices()
    End Sub

    Public Sub UpdateDevices()
        Dim devIndexes As List(Of String) = New List(Of String)()

        For i As Integer = 0 To usbIO.getInnoMakerDeviceCount() - 1
            Dim device As InnoMakerDevice = usbIO.getInnoMakerDevice(i)
            devIndexes.Add(device.deviceId.ToString())
        Next

        deviceComboBox.DataSource = devIndexes
    End Sub

    Private Function buildStandardFrame(ByVal frameId As String, ByVal frameData As String, ByVal echoId As UInteger) As Byte()
        Dim frame As UsbCan.innomaker_host_frame
        frame.data = New Byte(7) {}
        frame.echo_id = echoId
        frame.can_dlc = 8
        frame.channel = 0
        frame.flags = 0
        frame.reserved = 0
        frameId = Formatter.formatStringToHex(frameId, 8, True)
        frameData = Formatter.formatStringToHex(frameData, 16, True)
        Dim canIdArr As String() = frameId.Split(" "c)
        Dim canId As Byte() = {&H0, &H0, &H0, &H0}

        For i As Integer = 0 To canIdArr.Length - 1
            Dim b As String = canIdArr(canIdArr.Length - i - 1)
            canId(i) = CByte(Convert.ToInt32(b, 16))
        Next

        frame.can_id = System.BitConverter.ToUInt32(canId, 0)
        Dim dataByte As String() = frameData.Split(" "c)

        For i As Integer = 0 To dataByte.Length - 1
            Dim byteValue As String = dataByte(i)
            frame.data(i) = CByte(Convert.ToInt32(byteValue, 16))
        Next

        Return StructureHelper.StructToBytes(frame)
    End Function

    Public Sub setupSendTimer()
        Dim interval As Integer = Integer.Parse(SendIntervalTextBox.Text)

        If interval < 100 OrElse interval > 5000 Then
            Return
        End If

        If Integer.Parse(numbersendTextBox.Text) < 1 OrElse Integer.Parse(numbersendTextBox.Text) > 10000 Then
            Return
        End If

        Dim frameId As String = FrameIdTextBox.Text
        Dim frameData As String = DataTextBox.Text

        If currentDeivce Is Nothing OrElse currentDeivce.isOpen = False Then


            MessageBox.Show("Device Not Open")


            Return
        End If

        If curBitrateSelectIndex = -1 Then


            MessageBox.Show("BaudRate Not Right")


            Return
        End If

        If curWorkModeSelectIndex = -1 Then


            MessageBox.Show("Work Mode Not Right")


            Return
        End If

        If frameId.Length = 0 Then


            MessageBox.Show("Frame ID Not Right")


            Return
        End If

        If frameData.Length = 0 Then


            MessageBox.Show("Frame Data Not Right")


            Return
        End If

        sendTimer = New Timer(interval)
        numberSended = 0
        AddHandler sendTimer.Elapsed, New ElapsedEventHandler(AddressOf sendToDev)
        sendTimer.AutoReset = True
        sendTimer.Enabled = True
        updateSendBtn(1)
    End Sub

    Public Sub sendToDev(ByVal source As Object, ByVal e As System.Timers.ElapsedEventArgs)
        If delayedSendFrameId.Length = 0 Then
            delayedSendFrameId = FrameIdTextBox.Text
        End If

        If delayedSendFrameData.Length = 0 Then
            delayedSendFrameData = DataTextBox.Text
        End If

        If delayedSendFrameId.Length = 0 Then
            cancelSendTimer()


            DelayedSendBtn.Text = "Delayed Send"
            MessageBox.Show("Frame ID Not Right")


            DelayedSendBtn.Tag = 0
            Return
        End If

        If delayedSendFrameData.Length = 0 Then
            cancelSendTimer()


            DelayedSendBtn.Text = "Delayed Send"
            MessageBox.Show("Frame Data Not Right")


            DelayedSendBtn.Tag = 0
            Return
        End If

        Dim txc As innomaker_tx_context = innomaker_alloc_tx_context(can)

        If txc.echo_id = &HFF Then
            Return
        End If

        Dim standardFrameData As Byte() = buildStandardFrame(delayedSendFrameId, delayedSendFrameData, txc.echo_id)
        Dim result As Boolean = usbIO.sendInnoMakerDeviceBuf(currentDeivce, standardFrameData, standardFrameData.Length)

        If result Then
            Console.WriteLine("SEND:" & getHexString(standardFrameData))
        End If

        If mycheckIdType = CheckIDType.CheckIDTypeNone Then
        Else
            delayedSendFrameId = increaseFrameIdHexString(delayedSendFrameId, 8)
        End If

        If mycheckDataType = CheckDataType.CheckDataTypeNone Then
        Else
            delayedSendFrameData = increaseFrameIdHexString(delayedSendFrameData, 16)
        End If

        'If System.Threading.Interlocked.Increment(numberSended) = Integer.Parse(numbersendTextBox.Text) Then
        'celSendTimer()
        'Dim d As updateSendBtnDelegate = New updateSendBtnDelegate(AddressOf updateSendBtn)
        'Me.Invoke(d, 0)
        'End If

        If System.Threading.Interlocked.Increment(numberSended) = Integer.Parse(numbersendTextBox.Text) Then
            cancelSendTimer()
            Dim d As updateSendBtnDelegate = New updateSendBtnDelegate(AddressOf updateSendBtn)
            Me.Invoke(d, 0)
        End If




    End Sub

    Private Function increaseFrameIdHexString(ByVal frameId As String, ByVal bit As Integer) As String
        Dim increaseFrameId As String = ""
        frameId = Formatter.formatStringToHex(frameId, bit, True)
        Dim dataByte As String() = frameId.Split(" "c)
        Dim frameIdBytes As Byte() = New Byte(dataByte.Length - 1) {}
        Dim increaseBit As Boolean = True

        For i As Integer = dataByte.Length - 1 To 0
            Dim byteValue As String = dataByte(i)
            frameIdBytes(i) = Convert.ToByte(byteValue, 16)

            If increaseBit Then

                If frameIdBytes(i) + 1 > &HFF Then
                    frameIdBytes(i) = &H0
                    increaseBit = True
                Else
                    frameIdBytes(i) = CByte((frameIdBytes(i) + 1))
                    increaseBit = False
                End If
            End If
        Next

        For i As Integer = 0 To dataByte.Length - 1
            increaseFrameId += frameIdBytes(i).ToString("X2")

            If i <> dataByte.Length - 1 Then
                increaseFrameId += " "c
            End If
        Next

        Return increaseFrameId
    End Function

    Public Sub setupRecvTimer()
        recvTimer = New Timer(30)
        AddHandler recvTimer.Elapsed, New ElapsedEventHandler(AddressOf inputFromDev)
        recvTimer.AutoReset = True
        recvTimer.Enabled = True
    End Sub

    Public Sub inputFromDev(ByVal source As Object, ByVal e As System.Timers.ElapsedEventArgs)
        If currentDeivce Is Nothing OrElse currentDeivce.isOpen = False Then
            cancelRecvTimer()
            Return
        End If

        Dim frame As UsbCan.innomaker_host_frame = New UsbCan.innomaker_host_frame()
        Dim size As Integer = Marshal.SizeOf(frame)
        Dim inputBytes As Byte() = New Byte(size - 1) {}
        Dim result As Boolean = usbIO.getInnoMakerDeviceBuf(currentDeivce, inputBytes, size)

        If result Then
            Dim d As updateListViewDelegate = New updateListViewDelegate(AddressOf updateUI)
            Me.Invoke(d, inputBytes)
        End If
    End Sub

    Public Sub updateSendBtn(ByVal tag As Integer)
        If tag = 0 Then


            DelayedSendBtn.Text = "Delayed Send"

            DelayedSendBtn.Tag = 0
        Else


            DelayedSendBtn.Text = "Stop"


            DelayedSendBtn.Tag = 1
        End If
    End Sub

    Public Sub updateUI(ByVal inputBytes As Byte())
        Dim echoIdBytes As Byte() = New Byte(3) {}
        echoIdBytes(0) = inputBytes(0)
        echoIdBytes(1) = inputBytes(1)
        echoIdBytes(2) = inputBytes(2)
        echoIdBytes(3) = inputBytes(3)
        Dim echoId As UInt32 = BitConverter.ToUInt32(echoIdBytes, 0)
        Dim frameIdBytes As Byte() = New Byte(3) {}
        frameIdBytes(0) = inputBytes(4)
        frameIdBytes(1) = inputBytes(5)
        frameIdBytes(2) = inputBytes(6)
        frameIdBytes(3) = inputBytes(7)
        Dim frameId As UInt32 = BitConverter.ToUInt32(frameIdBytes, 0)
        Dim frameDataBytes As Byte() = New Byte(7) {}
        Buffer.BlockCopy(inputBytes, 12, frameDataBytes, 0, 8)
        Dim seqStr As String = ListView1.Items.Count.ToString()
        Dim systemTimeStr As String = DateTime.Now.ToString()
        Dim channelStr As String = "0"
        Dim directionStr As String = If(echoId = &HFFFFFFFF, "Recv", "Send")
        Dim frameIdStr As String = "0x" & frameId.ToString("X2")
        Dim frameTypeStr As String = "Data Frame"
        Dim frameFormatStr As String = "Standard Frame"
        Dim frameLengthStr As String = "8"
        Dim frameDataStr As String = getHexString(frameDataBytes)



        If echoId = &HFFFFFFFF Then

            If (frameId And &H20) = &H20000000 AndAlso mycheckErrorFrame = CheckErrorFrame.CheckErrorFrameOpen Then
                Return
            End If

            Dim lvi As ListViewItem = New ListViewItem()
            lvi.Text = ListView1.Items.Count.ToString()
            lvi.ForeColor = If(((frameId And &H20000000) = &H20000000), Color.Red, Color.Black)
            lvi.SubItems.Add(systemTimeStr)
            lvi.SubItems.Add(channelStr)
            lvi.SubItems.Add(directionStr)
            lvi.SubItems.Add(frameIdStr)
            lvi.SubItems.Add(frameTypeStr)
            lvi.SubItems.Add(frameFormatStr)
            lvi.SubItems.Add(frameLengthStr)
            lvi.SubItems.Add(frameDataStr)
            ListView1.BeginUpdate()
            ListView1.Items.Add(lvi)
            ListView1.EndUpdate()
            ListView1.Items(ListView1.Items.Count - 1).EnsureVisible()
        Else
            Dim txc As innomaker_tx_context = innomaker_get_tx_context(can, echoId)

            If txc.echo_id = &HFF Then
                'steve Return
            End If

            Dim lvi As ListViewItem = New ListViewItem()
            lvi.ForeColor = Color.Green
            lvi.Text = ListView1.Items.Count.ToString()
            lvi.SubItems.Add(systemTimeStr)
            lvi.SubItems.Add(channelStr)
            lvi.SubItems.Add(directionStr)
            lvi.SubItems.Add(frameIdStr)
            lvi.SubItems.Add(frameTypeStr)
            lvi.SubItems.Add(frameFormatStr)
            lvi.SubItems.Add(frameLengthStr)
            lvi.SubItems.Add(frameDataStr)
            TextBox2.Text = frameDataStr

            ListView1.BeginUpdate()
            ListView1.Items.Add(lvi)
            ListView1.EndUpdate()
            ListView1.Items(ListView1.Items.Count - 1).EnsureVisible()
            innomaker_free_tx_context(txc)
        End If
    End Sub

    Public Sub cancelRecvTimer()
        If recvTimer IsNot Nothing Then
            recvTimer.Enabled = False
            recvTimer.[Stop]()
            recvTimer = Nothing
        End If
    End Sub

    Public Sub cancelSendTimer()
        If sendTimer IsNot Nothing Then
            sendTimer.Enabled = False
            sendTimer.[Stop]()
            sendTimer = Nothing
        End If

        delayedSendFrameId = ""
        delayedSendFrameData = ""
        numberSended = 0
    End Sub

    Public Sub DoExport(ByVal listView As ListView, ByVal strFileName As String)
    End Sub

    Private Shared Function innomaker_alloc_tx_context(ByVal dev As innomaker_can) As innomaker_tx_context
        Dim _lock As Boolean = False
        dev.tx_ctx_lock.Enter(_lock)

        For i As UInteger = 0 To innomaker_MAX_TX_URBS - 1

            If dev.tx_context(i).echo_id = innomaker_MAX_TX_URBS Then
                dev.tx_context(i).echo_id = i
                Console.WriteLine("innomaker_alloc_tx_context" & i)
                dev.tx_ctx_lock.[Exit]()
                _lock = False
                Return dev.tx_context(i)
            End If
        Next

        dev.tx_ctx_lock.[Exit]()
        _lock = False
        Dim nullContext As innomaker_tx_context = New innomaker_tx_context()
        nullContext.echo_id = &HFF
        Return nullContext
    End Function

    Private Shared Sub innomaker_free_tx_context(ByVal txc As innomaker_tx_context)
        Console.WriteLine("innomaker_free_tx_context" & txc.echo_id)
        txc.echo_id = innomaker_MAX_TX_URBS
    End Sub

    Private Function innomaker_get_tx_context(ByVal dev As innomaker_can, ByVal id As UInteger) As innomaker_tx_context
        If id < innomaker_MAX_TX_URBS Then
            Dim _lock As Boolean = False
            dev.tx_ctx_lock.Enter(_lock)

            If dev.tx_context(id).echo_id = id Then
                dev.tx_ctx_lock.[Exit]()
                _lock = False
                Console.WriteLine("innomaker_get_tx_context" & id)
                Return dev.tx_context(id)
            End If

            dev.tx_ctx_lock.[Exit]()
            _lock = False
        End If

        Dim nullContext As innomaker_tx_context = New innomaker_tx_context()
        nullContext.echo_id = &HFF
        Return nullContext
    End Function

    Public Sub numberSendKeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If Not Char.IsNumber(e.KeyChar) AndAlso e.KeyChar <> ChrW(8) Then
            e.Handled = True
        End If
    End Sub

    Public Sub sendIntervalKeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If Not Char.IsNumber(e.KeyChar) AndAlso e.KeyChar <> ChrW(8) Then
            e.Handled = True
        End If
    End Sub

    Public Sub FrameIdTextBox_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
    End Sub

    Public Sub DataTextBox_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
    End Sub

    Public Class StructureHelper
        Public Shared Function StructToBytes(ByVal structObj As Object) As Byte()
            Dim size As Integer = Marshal.SizeOf(structObj)
            Dim buffer As IntPtr = Marshal.AllocHGlobal(size)

            Try
                Marshal.StructureToPtr(structObj, buffer, False)
                Dim bytes As Byte() = New Byte(size - 1) {}
                Marshal.Copy(buffer, bytes, 0, size)
                Return bytes
            Finally
                Marshal.FreeHGlobal(buffer)
            End Try
        End Function

        Public Shared Function ByteToStruct(ByVal bytes As Byte(), ByVal type As Type) As Object
            Dim size As Integer = Marshal.SizeOf(type)

            If size > bytes.Length Then
                Return Nothing
            End If

            Dim structPtr As IntPtr = Marshal.AllocHGlobal(size)
            Marshal.Copy(bytes, 0, structPtr, size)
            Dim obj As Object = Marshal.PtrToStructure(structPtr, type)
            Marshal.FreeHGlobal(structPtr)
            Return obj
        End Function
    End Class

    Public Class Formatter
        Public Shared Function formatString(ByVal originString As String, ByVal charactersInString As String) As String
            Dim aformatString As String = ""

            For Each c As Char In originString

                If charactersInString.Contains(c.ToString()) Then
                    aformatString += c
                End If
            Next

            Return aformatString
        End Function

        Private Shared Function dealWithString(ByVal str As String) As String
            Dim dealStr As String = ""
            Dim i As Integer = 0

            For Each c As Char In str

                If System.Threading.Interlocked.Increment(i) = 3 Then
                    dealStr += " "
                    i = 1
                End If

                dealStr += c.ToString()
            Next

            Return dealStr
        End Function

        Public Shared Function formatStringToHex(ByVal originString As String, ByVal limitLength As Integer, ByVal padding As Boolean) As String
            If padding Then
                originString = originString.Replace(" ", "")
            End If

            Dim str As String = formatString(originString, "0123456789ABCDEFabcdef")

            If str.Length > limitLength Then
                str = str.Substring(0, limitLength)
            End If

            If str.Length = 0 Then
                str = "00"
            End If

            If padding Then
                str = dealWithString(str)
            End If

            Return str
        End Function

        Public Shared Sub adjustTextFieldToHex(ByVal textBox As TextBox, ByVal limitLength As Integer, ByVal padding As Boolean)
            Dim originString As String = textBox.Text

            If padding Then
                originString = originString.Replace(" ", "")
            End If

            Dim str As String = formatString(originString, "0123456789ABCDEFabcdef")

            If str.Length > limitLength Then
                str = str.Substring(0, limitLength)
            End If

            If padding Then
                str = dealWithString(str)
            End If

            textBox.Text = str
        End Sub
    End Class

    Public Sub LangCombox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)

    End Sub

    Public Sub ApplyResources()

    End Sub

    Public Sub FrameIdMouseEnter(ByVal sender As Object, ByVal e As EventArgs)

    End Sub

    Public Sub FrameIdMouseLeave(ByVal sender As Object, ByVal e As EventArgs)
        ' Me.toolTip1.Hide(FrameIdTextBox)
    End Sub

    Public Sub DateTextBoxMouseEnter(ByVal sender As Object, ByVal e As EventArgs)

    End Sub

    Public Sub DateTextBoxMouseLeave(ByVal sender As Object, ByVal e As EventArgs)
        'Me.toolTip1.Hide(DataTextBox)
    End Sub

    Private Sub OpenDeviceBtn_Click_1(sender As Object, e As EventArgs) Handles OpenDeviceBtn.Click
        If OpenDeviceBtn.Tag.Equals(1) Then
            _closeDevice()
        Else
            _openDevice()
        End If
    End Sub

    Private Sub deviceComboBox_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles deviceComboBox.SelectedIndexChanged
        currentDeivce = usbIO.getInnoMakerDevice(deviceComboBox.SelectedIndex)
    End Sub

    Private Sub BaudRateComboBox_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles BaudRateComboBox.SelectedIndexChanged
        curBitrateSelectIndex = BaudRateComboBox.SelectedIndex
    End Sub

    Private Sub sendbtn_Click_1(sender As Object, e As EventArgs) Handles sendbtn.Click


        Dim frameId As String = FrameIdTextBox.Text
        Dim frameData As String = DataTextBox.Text

        If currentDeivce Is Nothing OrElse currentDeivce.isOpen = False Then


            MessageBox.Show("Device Not Open")


            Return
        End If

        If curBitrateSelectIndex = -1 Then


            MessageBox.Show("BaudRate Not Right")


            Return
        End If

        If curWorkModeSelectIndex = -1 Then


            MessageBox.Show("Work Mode Not Right")


            Return
        End If

        If frameId.Length = 0 Then


            MessageBox.Show("Frame ID Not Right")


            Return
        End If

        If frameData.Length = 0 Then


            MessageBox.Show("Frame Data Not Right")


            Return
        End If


        ' find an empty context to keep track of transmission 
        Dim txc As innomaker_tx_context = innomaker_alloc_tx_context(can)

        If txc.echo_id = &HFF Then
            ' MessageBox.Show("发送繁忙 ERROR:[NETDEV_TX_BUSY]");
            Return
        End If

        Dim standardFrameData = Me.buildStandardFrame(frameId, frameData, txc.echo_id)
        Dim result = usbIO.sendInnoMakerDeviceBuf(currentDeivce, standardFrameData, standardFrameData.Length)

        If result Then
            Console.WriteLine("SEND:" & getHexString(standardFrameData))
        Else
        End If





    End Sub

    Private Sub modeComboBox_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles modeComboBox.SelectedIndexChanged
        curWorkModeSelectIndex = modeComboBox.SelectedIndex
    End Sub

    Private Sub ListView_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub
End Class
Class innomaker_tx_context
    Public echo_id As UInt32
End Class

Class innomaker_can
    Public tx_ctx_lock As SpinLock
    Public tx_context As innomaker_tx_context()
End Class